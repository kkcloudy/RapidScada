#!/bin/sh
chmod +x /opt/scada/restart_apache.sh
chmod +x /opt/scada/scadarestart.sh
chmod +x /opt/scada/scadastart.sh
chmod +x /opt/scada/scadastop.sh
chmod +x /opt/scada/svc_install.sh
chmod +x /opt/scada/svc_uninstall.sh
chmod +x /opt/scada/ScadaAgent/svc_restart.sh
chmod +x /opt/scada/ScadaAgent/svc_start.sh
chmod +x /opt/scada/ScadaAgent/svc_stop.sh
chmod +x /opt/scada/ScadaComm/svc_restart.sh
chmod +x /opt/scada/ScadaComm/svc_start.sh
chmod +x /opt/scada/ScadaComm/svc_stop.sh
chmod +x /opt/scada/ScadaServer/svc_restart.sh
chmod +x /opt/scada/ScadaServer/svc_start.sh
chmod +x /opt/scada/ScadaServer/svc_stop.sh
