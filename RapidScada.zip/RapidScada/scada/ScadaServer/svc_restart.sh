#!/bin/sh
service scadaserver stop
service scadaserver start
