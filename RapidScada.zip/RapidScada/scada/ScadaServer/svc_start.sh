#!/bin/sh
service scadaserver start
