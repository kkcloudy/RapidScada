#!/bin/sh
service scadaserver stop
