#!/bin/sh
service scadacomm stop
