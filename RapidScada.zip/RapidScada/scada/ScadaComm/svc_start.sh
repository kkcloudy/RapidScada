#!/bin/sh
service scadacomm start
