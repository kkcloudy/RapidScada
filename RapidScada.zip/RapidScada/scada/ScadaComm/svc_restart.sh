#!/bin/sh
service scadacomm stop
service scadacomm start
