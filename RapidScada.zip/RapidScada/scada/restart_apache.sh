#!/bin/sh
service apache2 restart
