#!/bin/sh
update-rc.d -f scadaagent remove
update-rc.d -f scadaserver remove
update-rc.d -f scadacomm remove
