#!/bin/sh
service scadaagent stop
service scadaagent start
