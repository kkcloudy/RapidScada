#!/bin/sh
service scadaagent stop
