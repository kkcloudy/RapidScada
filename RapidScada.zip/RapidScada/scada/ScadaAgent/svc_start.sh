#!/bin/sh
service scadaagent start
